MONO Active Materials v0.5
Includes v0.4 active 32x32 cellular chunks and v0.5 cached material rendering with moisture/heat-influenced trees, weather settings, sword slash, and wind slider.
Run through a static HTTP server or upload the extracted folder to Netlify Drop. index.html is the entry point.
Simulation uses 30Hz cap, visual animation uses requestAnimationFrame. Performance metrics are estimates measured in the browser; actual device performance varies.
This is the material prototype, not the full 6SKULL game or MONO v5.5 overworld.
