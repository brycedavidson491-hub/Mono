/* MONO v0.5: active chunk cellular materials. Deterministic hash randomness, fixed typed-array buffers. */
export const MATERIAL={AIR:0,STONE:1,SOIL:2,WOOD:3,PLANT:4,WATER:5,ASH:6};
const {AIR,STONE,SOIL,WOOD,PLANT,WATER,ASH}=MATERIAL;
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
export class CellularWorld {
 constructor(w,h,seed=1301,chunkSize=32){this.w=w;this.h=h;this.seed=seed;this.tick=0;this.cs=chunkSize;this.cw=Math.ceil(w/chunkSize);this.ch=Math.ceil(h/chunkSize);const n=w*h;this.mat=new Uint8Array(n);this.heat=new Float32Array(n);this.moisture=new Float32Array(n);this.age=new Uint16Array(n);this.nextMat=new Uint8Array(n);this.nextHeat=new Float32Array(n);this.nextMoisture=new Float32Array(n);this.active=new Uint8Array(this.cw*this.ch);this.nextActive=new Uint8Array(this.active.length);this.dirty=new Uint8Array(this.active.length);this.idle=new Uint8Array(this.active.length);this.active.fill(1);this.dirty.fill(1);this.stats={active:0,visited:0,changed:0};}
 index(x,y){return y*this.w+x} inside(x,y){return x>=0&&y>=0&&x<this.w&&y<this.h}
 random(x,y,salt=0){let n=(Math.imul(x+1,374761393)^Math.imul(y+1,668265263)^Math.imul(this.tick+1,2246822519)^Math.imul(salt+1,3266489917)^this.seed)>>>0;n=Math.imul(n^(n>>>13),1274126177);return ((n^(n>>>16))>>>0)/4294967296}
 wake(x,y){if(!this.inside(x,y))return;const cx=(x/this.cs)|0,cy=(y/this.cs)|0;for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){const xx=cx+dx,yy=cy+dy;if(xx>=0&&yy>=0&&xx<this.cw&&yy<this.ch){const ci=yy*this.cw+xx;this.active[ci]=1;this.nextActive[ci]=1;this.idle[ci]=0;}}this.dirty[cy*this.cw+cx]=1;}
 set(x,y,m,heat=0,moisture=0){if(!this.inside(x,y))return;const i=this.index(x,y);this.mat[i]=m;this.heat[i]=heat;this.moisture[i]=moisture;this.age[i]=0;this.wake(x,y)}
 sample(x,y){x=clamp(x|0,0,this.w-1);y=clamp(y|0,0,this.h-1);const i=this.index(x,y);return {material:this.mat[i],heat:this.heat[i],moisture:this.moisture[i],age:this.age[i]}}
 step(){const {w,h,mat,heat,moisture,age,nextMat,nextHeat,nextMoisture,cs,cw,ch}=this;nextMat.set(mat);nextHeat.set(heat);nextMoisture.set(moisture);this.nextActive.fill(0);let active=0,visited=0,changed=0;
 for(let cy=0;cy<ch;cy++)for(let cx=0;cx<cw;cx++){const ci=cy*cw+cx;if(!this.active[ci])continue;active++;let dynamic=false;const maxY=Math.min(h,(cy+1)*cs),maxX=Math.min(w,(cx+1)*cs);
 for(let y=cy*cs;y<maxY;y++)for(let x=cx*cs;x<maxX;x++){visited++;const i=y*w+x,m=mat[i],hv=heat[i],mv=moisture[i];let nh=hv*.89,nw=mv*.975,plantNear=false,soilPick=-1,soilCount=0;
 const neighbors=[y>0?i-w:-1,x+1<w?i+1:-1,y+1<h?i+w:-1,x>0?i-1:-1];
 for(let d=0;d<4;d++){const j=neighbors[d];if(j<0)continue;nh+=heat[j]*.0275;nw+=(moisture[j]-mv)*.035;if(mat[j]===PLANT)plantNear=true;if(mat[j]===SOIL&&moisture[j]>.28){soilCount++;if(this.random(x,y,13+d)<1/soilCount)soilPick=j;}}
 if(m===WATER)nw=1;nh=clamp(nh,0,1);nw=clamp(nw,0,1);nextHeat[i]=nh;nextMoisture[i]=nw;const r=this.random(x,y);
 if(m===PLANT){if(nh>.62){nextMat[i]=ASH;nextHeat[i]=.95}else if(nw<.11&&r<.018)nextMat[i]=SOIL;else if(r<.018&&nw>.4&&soilPick>=0){nextMat[soilPick]=PLANT;this.wakeNext(soilPick);}}
 else if(m===WOOD){if(nh>.68&&r<.23){nextMat[i]=ASH;nextHeat[i]=1;}}
 else if(m===ASH){if(nh<.12&&nw>.45&&r<.025)nextMat[i]=SOIL;}
 else if(m===SOIL){if(nw>.55&&nh<.45&&r<.002&&plantNear)nextMat[i]=PLANT;}
 else if(m===STONE){if(nw>.78&&r<.0007)nextMat[i]=SOIL;}
 if(m===WATER&&y+1<h){const j=i+w;if(mat[j]===AIR){nextMat[j]=WATER;nextMat[i]=AIR;this.wakeNext(j);}else if(mat[j]===SOIL)nextMoisture[j]=1;}
 const diff=nextMat[i]!==m||Math.abs(nh-hv)>.004||Math.abs(nw-mv)>.004;
 if(diff){changed++;dynamic=true;this.dirty[ci]=1;}if(nh>.015||m===WATER||(m===PLANT&&nw>.28&&nw<.9))dynamic=true;
 age[i]=nextMat[i]===m?Math.min(65535,age[i]+1):0;
 }
 if(dynamic){this.idle[ci]=0;this.nextActive[ci]=1;for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){const xx=cx+dx,yy=cy+dy;if(xx>=0&&yy>=0&&xx<cw&&yy<ch)this.nextActive[yy*cw+xx]=1;}}
 else if(++this.idle[ci]<5)this.nextActive[ci]=1;
 }
 this.mat=nextMat;this.nextMat=mat;this.heat=nextHeat;this.nextHeat=heat;this.moisture=nextMoisture;this.nextMoisture=moisture;this.active.set(this.nextActive);this.tick++;this.stats={active,visited,changed};}
 wakeNext(i){const x=i%this.w,y=(i/this.w)|0,cx=(x/this.cs)|0,cy=(y/this.cs)|0;for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){const xx=cx+dx,yy=cy+dy;if(xx>=0&&yy>=0&&xx<this.cw&&yy<this.ch)this.nextActive[yy*this.cw+xx]=1;}this.dirty[cy*this.cw+cx]=1;}
}
